-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: sopoong
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `good`
--

DROP TABLE IF EXISTS `good`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `good` (
  `good_idx` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL,
  `travel_idx` bigint NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`good_idx`),
  KEY `fk_travel_like_idx` (`travel_idx`),
  KEY `fk_user_good` (`user_id`),
  CONSTRAINT `fk_travel_good` FOREIGN KEY (`travel_idx`) REFERENCES `travel` (`travel_idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_good` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `good`
--

LOCK TABLES `good` WRITE;
/*!40000 ALTER TABLE `good` DISABLE KEYS */;
INSERT INTO `good` VALUES (2,'maiplking',47,'2021-08-19 08:21:20'),(6,'sense168',47,'2021-08-19 08:33:19'),(21,'rlaghtjr2',107,'2021-08-19 14:24:32'),(29,'maiplking',132,'2021-08-19 15:18:41'),(38,'maiplking',131,'2021-08-19 16:42:06'),(65,'wjddnjsgur2',123,'2021-08-19 20:34:07'),(70,'wjddnjsgur2',125,'2021-08-19 20:34:46'),(79,'wjddnjsgur2',129,'2021-08-19 20:48:03'),(86,'wjddnjsgur2',127,'2021-08-19 21:54:38'),(87,'wjddnjsgur2',121,'2021-08-19 21:54:39'),(89,'wjddnjsgur2',131,'2021-08-19 21:58:38'),(90,'wjddnjsgur2',132,'2021-08-19 21:58:39'),(91,'wjddnjsgur2',47,'2021-08-19 21:58:41'),(92,'wjddnjsgur2',137,'2021-08-19 23:22:40'),(93,'wjddnjsgur2',143,'2021-08-19 23:22:41'),(95,'wpffl3333',144,'2021-08-19 23:45:23'),(96,'wpffl3333',138,'2021-08-19 23:45:28'),(97,'wpffl3333',143,'2021-08-20 00:41:40'),(101,'wjddnjsgur',144,'2021-08-20 01:39:54'),(102,'hoseok76081024',146,'2021-08-20 01:50:00');
/*!40000 ALTER TABLE `good` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:58:31
