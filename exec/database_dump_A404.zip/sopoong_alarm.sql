-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: sopoong
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alarm`
--

DROP TABLE IF EXISTS `alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alarm` (
  `alarm_idx` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL,
  `alarm_category` int NOT NULL,
  `alarm_check` tinyint DEFAULT '0',
  `good_idx` bigint DEFAULT NULL,
  `relation_idx` bigint DEFAULT NULL,
  `travel_idx` bigint DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`alarm_idx`),
  KEY `fk_like_alarm_idx` (`travel_idx`),
  KEY `fk_follow_alarm` (`relation_idx`),
  KEY `fk_good_alarm` (`good_idx`),
  CONSTRAINT `fk_follow_alarm` FOREIGN KEY (`relation_idx`) REFERENCES `relation` (`relation_idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_good_alarm` FOREIGN KEY (`good_idx`) REFERENCES `good` (`good_idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_travel_alarm` FOREIGN KEY (`travel_idx`) REFERENCES `travel` (`travel_idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=463 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm`
--

LOCK TABLES `alarm` WRITE;
/*!40000 ALTER TABLE `alarm` DISABLE KEYS */;
INSERT INTO `alarm` VALUES (29,'wjddnjsgur',3,1,NULL,NULL,98,NULL),(31,'wjddnjsgur',3,1,NULL,NULL,100,NULL),(32,'wjddnjsgur',3,1,NULL,NULL,101,NULL),(33,'wjddnjsgur',3,1,NULL,NULL,102,NULL),(34,'wjddnjsgur',3,1,NULL,NULL,103,NULL),(36,'wjddnjsgur',3,1,NULL,NULL,105,NULL),(37,'wjddnjsgur',3,1,NULL,NULL,107,NULL),(42,'maiplking',1,1,2,NULL,NULL,NULL),(58,'maiplking',1,1,6,NULL,NULL,NULL),(59,'wjddnjsgur2',3,0,NULL,NULL,121,NULL),(61,'wjddnjsgur2',3,0,NULL,NULL,123,NULL),(62,'wjddnjsgur2',3,0,NULL,NULL,124,NULL),(63,'wjddnjsgur2',3,0,NULL,NULL,125,NULL),(65,'wjddnjsgur2',3,0,NULL,NULL,127,NULL),(66,'wjddnjsgur2',3,0,NULL,NULL,129,NULL),(68,'wjddnjsgur2',3,0,NULL,NULL,131,NULL),(84,'wjddnjsgur2',2,0,NULL,83,NULL,NULL),(85,'wjddnjsgur2',1,0,21,NULL,NULL,NULL),(86,'wjddnjsgur2',3,0,NULL,NULL,132,NULL),(94,'maiplking',1,1,29,NULL,NULL,NULL),(241,'maiplking',1,1,38,NULL,NULL,NULL),(381,'wjddnjsgur',1,1,65,NULL,NULL,NULL),(387,'wjddnjsgur',1,1,70,NULL,NULL,NULL),(405,'maiplking',1,1,79,NULL,NULL,NULL),(424,'wjddnjsgur',1,1,86,NULL,NULL,NULL),(425,'wjddnjsgur',1,1,87,NULL,NULL,NULL),(428,'maiplking',1,1,89,NULL,NULL,NULL),(429,'maiplking',1,1,90,NULL,NULL,NULL),(430,'maiplking',1,1,91,NULL,NULL,NULL),(432,'rlaghtjr2',2,1,NULL,359,NULL,NULL),(433,'hoseok5020',3,0,NULL,NULL,140,NULL),(434,'wjddnjsgur2',3,0,NULL,NULL,144,NULL),(435,'hoseok76081024',2,1,NULL,360,NULL,NULL),(436,'hoseok5020',2,0,NULL,361,NULL,NULL),(437,'hoseok5020',1,0,92,NULL,NULL,NULL),(438,'hoseok76081024',1,1,93,NULL,NULL,NULL),(440,'maiplking',1,1,95,NULL,NULL,NULL),(441,'hoseok5020',1,0,96,NULL,NULL,NULL),(442,'hoseok76081024',2,1,NULL,362,NULL,NULL),(443,'hoseok76081024',2,1,NULL,363,NULL,NULL),(444,'hoseok5020',2,0,NULL,364,NULL,NULL),(445,'hoseok76081024',1,1,97,NULL,NULL,NULL),(452,'maiplking',1,1,101,NULL,NULL,NULL),(453,'maiplking',1,1,102,NULL,NULL,NULL),(456,'wpffl3333',2,1,NULL,369,NULL,NULL),(457,'hoseok5020',3,0,NULL,NULL,147,NULL),(458,'maiplking',2,1,NULL,370,NULL,NULL),(459,'wjddnjsgur',3,1,NULL,NULL,148,NULL),(460,'maiplking',2,1,NULL,371,NULL,NULL),(461,'wjddnjsgur',3,0,NULL,NULL,149,NULL);
/*!40000 ALTER TABLE `alarm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:58:39
