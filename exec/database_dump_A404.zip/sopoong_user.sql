-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: sopoong
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_idx` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL,
  `user_email` varchar(45) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `user_nickname` varchar(20) NOT NULL,
  `auth_number` varchar(45) DEFAULT NULL,
  `user_preference` json DEFAULT NULL,
  `user_is_visible` tinyint DEFAULT '1',
  `user_alarm` int DEFAULT '7',
  `user_comment` varchar(256) DEFAULT NULL,
  `image_idx` bigint DEFAULT '2',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_idx`),
  UNIQUE KEY `user_id_UNIQUE` (`user_id`),
  UNIQUE KEY `user_email_UNIQUE` (`user_email`),
  UNIQUE KEY `user_nickname_UNIQUE` (`user_nickname`),
  KEY `fk_image_user_idx` (`image_idx`),
  CONSTRAINT `fk_image_user` FOREIGN KEY (`image_idx`) REFERENCES `image` (`image_idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (56,'wjddnjsgur','modernseoul@naver.com','{bcrypt}$2a$10$mNxxJMyDBDhsvuNh.W7hfebUBSU.dWENkf2EFZu1MspVJC6ZvaylK','워녁','AUTH',NULL,1,7,NULL,2,'2021-08-19 03:24:19'),(57,'wjddnjsgur2','hyuk21gm@gmail.com','{bcrypt}$2a$10$./3K9L0NzLZuH3Y5uwoUyOXgDNczzae.yATjtNQxrVlotry8/USKK','워녁2','AUTH',NULL,1,7,'코딩싫어',152,'2021-08-19 03:38:16'),(58,'maiplking','maiplking@naver.com','{bcrypt}$2a$10$a57KjGVI3PovGaYqPv/OGeIETsXEIx68Vcs.3vpyWEJC6BO22O4Ya','제발','AUTH',NULL,1,7,'누구세용?',333,'2021-08-19 04:47:30'),(59,'wjddnjsgur3','wonhyeok.contact@gmail.com','{bcrypt}$2a$10$fSf06/w4q2hvVHUqim7K0OhXo1PFPfgdFKC4bqa/BLoVjk5cdKz6y','워녁3','u82W82Sh',NULL,1,7,NULL,2,'2021-08-19 07:58:50'),(60,'sense168','sense168@naver.com','{bcrypt}$2a$10$1ygRgV3CKMg1kIbMfWNNqOrz.LQgjPN8g7sgp4F50jF3QXvam9tHK','sense168','AUTH',NULL,1,7,NULL,2,'2021-08-19 08:19:24'),(64,'rlaghtjr2','rlaghtjr2@naver.com','{bcrypt}$2a$10$rllmh/vtVQI2iPT9.KJFaeJrJi657Uhk/waB.yWVX3KQFu7ifoT6G','호점','AUTH',NULL,1,7,'null',318,'2021-08-19 13:16:22'),(65,'wpffl3333','wpffl3333@naver.com','{bcrypt}$2a$10$2KBx4OTFQbwVwMDvCfDb8eODJgY0wPl00m6Mjkpd477jJxOryK8/i','윤정','AUTH',NULL,1,7,'여행 가고 싶다!',284,'2021-08-19 15:02:22'),(66,'qweqwe','openpnu@naver.com','{bcrypt}$2a$10$ZhlE4yWDe6yL2WXKbr1wqOo9YVTM5PBvNctHzIar.oOVAELLzrlZ6','qeqeqe','AUTH',NULL,1,7,NULL,2,'2021-08-19 19:34:09'),(67,'hoseok5020','asdf@adsf.com','{bcrypt}$2a$10$PmGx02B4u1E/iAh27cQRcuoAOcSddknKNNwon3mVo7vd31vwMgSaC','김몽석','AUTH',NULL,1,7,'죽고싶다',319,'2021-08-19 22:47:48'),(68,'hoseok76081024','asdfasd@asdf.com','{bcrypt}$2a$10$8DpHmamyIHlv6/PCs9JgP.MscYeX6uoX68PyY3hD0kpAfBmJTza12','몽석','AUTH',NULL,1,7,'null',317,'2021-08-19 22:56:18'),(69,'wjddl3333','wpffl3332@naver.com','{bcrypt}$2a$10$X82/57MsWAjWkZJRFCIYLu9M8IB5Rb8Vd/AoCdHwdcg4wjwh3MXzG','윤댕','o1a9mo95',NULL,1,7,NULL,2,'2021-08-20 00:08:41');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20 11:58:34
